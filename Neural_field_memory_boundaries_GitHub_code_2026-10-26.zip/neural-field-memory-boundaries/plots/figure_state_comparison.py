"""Render the state-observation comparison from the saved fit records.

No fitting, filtering of outcomes, file loading, or saving is performed here.
The returned figure carries ``state_comparison_summary`` for numerical audits.
"""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter, LogLocator, NullFormatter


GROUPS = ("ordinary", "spread", "adaptive_boundary")
LABELS = ("Ordinary", "Spread", "Adaptive")
COLORS = {"ordinary": "#6B7280", "spread": "#0072B2", "adaptive_boundary": "#D55E00"}
SIGMAS = (0.005, 0.02)
METRICS = (
    ("saddle_branch_relative_rmse", 100.0, "Saddle-branch RMSE (%)"),
    ("fold_absolute_error", 1000.0, r"Fold error, $|\widehat\mu_f-\mu_f|$ ($10^{-3}$)"),
    ("primary_pulse", 100.0, "Erasure-threshold error (%)"),
)

STYLE = {
    "font.family": "serif",
    "font.serif": ["STIXGeneral", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 9.5,
    "axes.labelsize": 9.5,
    "axes.titlesize": 9.5,
    "axes.titleweight": "normal",
    "xtick.labelsize": 8.5,
    "ytick.labelsize": 8.5,
    "legend.fontsize": 8.5,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 0.7,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
}


def _records(data):
    expected_seeds = set(data["protocol"]["seeds"])
    if len(expected_seeds) != 30:
        raise ValueError("Fig. 2 requires all 30 paired repetitions.")
    expected = {(sigma, seed, group) for sigma in SIGMAS
                for seed in expected_seeds for group in GROUPS}
    actual = [(float(row["sigma"]), row["seed"], row["group"])
              for row in data["records"]]
    if len(actual) != len(expected) or set(actual) != expected:
        raise ValueError("Fig. 2 requires the complete 180-record state comparison.")
    return {(sigma, group): sorted(
        (row for row in data["records"]
         if float(row["sigma"]) == sigma and row["group"] == group),
        key=lambda row: row["seed"])
        for sigma in SIGMAS for group in GROUPS}


def _values(rows, key, scale):
    values = np.asarray([
        row["pulse_relative_errors"][2] if key == "primary_pulse" else row[key]
        for row in rows], dtype=float) * scale
    if not np.isfinite(values).all() or np.any(values <= 0):
        raise ValueError(f"Nonpositive or unavailable {key}; an explicit failure display is required.")
    return values


def _median_label(value):
    return f"{value:.3f}" if value < 0.1 else f"{value:.2f}"


def render(data):
    """Return Fig. 2: metric rows, noise-level columns, and every saved fit."""
    records = _records(data)
    summary = []
    # The same seed has the same offset in every panel. No vertical jitter is used.
    jitter = np.random.default_rng(31415).permutation(np.linspace(-0.20, 0.16, 30))
    with plt.rc_context(STYLE):
        fig, axes = plt.subplots(3, 2, figsize=(7.0, 6.65), sharex=True, sharey="row")
        for row_index, (key, scale, ylabel) in enumerate(METRICS):
            row_values = []
            for column, sigma in enumerate(SIGMAS):
                ax = axes[row_index, column]
                for x, group in enumerate(GROUPS):
                    rows = records[sigma, group]
                    values = _values(rows, key, scale)
                    row_values.extend(values)
                    incomplete = np.asarray([
                        key == "saddle_branch_relative_rmse" and fit["branch_missing_count"] > 0
                        for fit in rows], dtype=bool)
                    color = COLORS[group]
                    ax.scatter(x + jitter[~incomplete], values[~incomplete],
                               s=13, color=color, alpha=0.60, linewidths=0,
                               zorder=3, clip_on=True)
                    if incomplete.any():
                        ax.scatter(x + jitter[incomplete], values[incomplete],
                                   marker="^", s=24, facecolors="white", edgecolors=color,
                                   linewidths=0.85, zorder=4, clip_on=True)
                    low, median, high = np.quantile(values, [0.1, 0.5, 0.9])
                    # Offset the summary slightly to keep all individual points visible.
                    center = x + 0.25
                    ax.plot([center, center], [low, high], color=color, lw=1.6, zorder=5)
                    ax.plot([center - 0.045, center + 0.045], [low, low], color=color, lw=1.0, zorder=5)
                    ax.plot([center - 0.045, center + 0.045], [high, high], color=color, lw=1.0, zorder=5)
                    ax.plot(center, median, marker="o", ms=5.0, color=color,
                            markeredgecolor="white", markeredgewidth=0.6, zorder=6)
                    ax.annotate(_median_label(median), (center, median),
                                xytext=(5, 0), textcoords="offset points",
                                fontsize=8.5, color="#222222", va="center", zorder=7)
                    summary.append({"metric": key, "sigma": sigma, "group": group,
                                    "count": len(values), "minimum": float(values.min()),
                                    "q10": float(low), "median": float(median),
                                    "q90": float(high), "maximum": float(values.max()),
                                    "marked_incomplete": int(incomplete.sum())})

                ax.set_yscale("log")
                ax.yaxis.set_major_locator(LogLocator(base=10, subs=(1,), numticks=9))
                ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}"))
                ax.yaxis.set_minor_locator(LogLocator(base=10, subs=(2, 5), numticks=30))
                ax.yaxis.set_minor_formatter(NullFormatter())
                ax.grid(axis="y", which="major", color="#E2E5E8", lw=0.5, zorder=0)
                ax.tick_params(axis="y", which="major", length=3, pad=3)
                ax.tick_params(axis="y", which="minor", length=1.8)
                ax.tick_params(axis="x", length=0, pad=6)
                ax.set_xlim(-0.42, 2.67)
                ax.set_xticks(range(3), LABELS)
                ax.text(0.0, 1.035, f"({chr(97 + 2 * row_index + column)})",
                        transform=ax.transAxes, fontweight="bold", fontsize=9.5,
                        ha="left", va="bottom")
                if row_index == 0:
                    ax.set_title(rf"$\sigma={sigma:g}$", pad=11)
                if column == 0:
                    ax.set_ylabel(ylabel, labelpad=7)
                if row_index == 2:
                    ax.tick_params(axis="x", labelbottom=True)

            # Shared scales include every outcome, including incomplete-branch RMSEs.
            limits = (min(row_values) / 1.45, max(row_values) * 1.65)
            for ax in axes[row_index]:
                ax.set_ylim(*limits)

        n_incomplete = sum(row["branch_missing_count"] > 0
                           for row in records[0.02, "ordinary"])
        axes[0, 1].text(0.98, 0.97, f"{n_incomplete}/30 incomplete branches",
                        transform=axes[0, 1].transAxes, ha="right", va="top",
                        fontsize=8.5, color="#444444")
        handles = [
            Line2D([], [], marker="o", ms=3.5, ls="", color="#777777",
                   alpha=0.65, label="Individual fit"),
            Line2D([], [], marker="o", ms=5.0, lw=1.4, color="#333333",
                   label="Median and 10–90% range"),
            Line2D([], [], marker="^", ms=5.0, ls="", markerfacecolor="white",
                   markeredgecolor="#6B7280", label="Incomplete branch"),
        ]
        fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.53, 0.018),
                   frameon=False, ncol=3, handlelength=1.5, columnspacing=1.6,
                   handletextpad=0.55)
        fig.subplots_adjust(left=0.12, right=0.98, top=0.94, bottom=0.105,
                            hspace=0.24, wspace=0.16)
        fig.state_comparison_summary = summary
        return fig
