"""Publication layout for the saved fixed-design calibration experiment.

Only the stored fits and bootstrap summaries are read.  ``render`` returns
an unsaved Matplotlib figure; it never fits a model or resamples the data.
"""
from pathlib import Path
import json

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FuncFormatter, NullFormatter
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "joint_initial"
GROUPS = ("ordinary", "true_far_boundary", "true_near_boundary")
TAUS = np.array([0.0, 0.005, 0.02])
COLORS = {
    "ordinary": "#6B7280",
    "true_far_boundary": "#0072B2",
    "true_near_boundary": "#D55E00",
}
MARKERS = {"ordinary": "o", "true_far_boundary": "s", "true_near_boundary": "D"}
LABELS = {
    "ordinary": "Ordinary",
    "true_far_boundary": r"Boundary, $\mu=0.45$",
    "true_near_boundary": r"Boundary, $\mu=0.735$",
}
RC = {
    "font.family": "serif",
    "font.serif": ["STIXGeneral", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 9.5,
    "axes.labelsize": 9.5,
    "axes.titlesize": 9.5,
    "axes.titleweight": "normal",
    "xtick.labelsize": 8.5,
    "ytick.labelsize": 8.5,
    "legend.fontsize": 8.5,
    "legend.frameon": False,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 0.7,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
}


def _load():
    data = json.loads((SOURCE / "results.json").read_text(encoding="utf-8"))
    summary = json.loads((SOURCE / "tables" / "summary.json").read_text(encoding="utf-8"))
    seeds = set(data["protocol"]["seeds"])
    expected = {(seed, group, tau) for seed in seeds for group in GROUPS for tau in TAUS}
    actual = [(r["seed"], r["group"], float(r["tau"])) for r in data["records"]]
    if len(seeds) != 30 or len(actual) != 270 or set(actual) != expected:
        raise ValueError("Figure 4 requires the 270 saved fits, with 30 paired seeds per cell.")
    if len(summary["variance"]) != 18 or len(summary["degradation"]) != 12:
        raise ValueError("The saved variance and inflation summaries are incomplete.")
    if any(r["count"] != 30 for r in summary["quality"]):
        raise ValueError("Every design/calibration cell must retain all 30 fits.")
    return data, summary


def _cell(summary, group, tau, target, table="variance"):
    matches = [r for r in summary[table]
               if r["group"] == group and r["tau"] == tau and r["target"] == target]
    if len(matches) != 1:
        raise ValueError(f"Expected one stored summary for {group}, {tau}, {target}.")
    return matches[0]


def _panel(ax, letter, title):
    ax.set_title(rf"$\mathbf{{({letter})}}$  {title}", loc="left", pad=8)
    ax.tick_params(length=3, width=0.7, pad=3)
    ax.set_axisbelow(True)
    ax.grid(axis="y", color="#E2E5E8", linewidth=0.5)


def _log_axis(ax, ticks, limits):
    ax.set_yscale("log")
    ax.set_ylim(*limits)
    ax.yaxis.set_major_locator(FixedLocator(ticks))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}"))
    ax.yaxis.set_minor_locator(FixedLocator([]))
    ax.yaxis.set_minor_formatter(NullFormatter())


def _tau_axis(ax):
    # The physical distances are 0 -> 5 -> 20, not three categorical positions.
    ax.set_xlim(-1.2, 21.5)
    ax.set_xticks(1000 * TAUS, ["0", "5", "20"])
    ax.set_xlabel(r"Calibration SD $\tau$ ($\times10^{-3}$)")


def _intervals(ax, x, low, high, color):
    # Draw the saved percentile endpoints directly: a percentile interval need
    # not bracket the original statistic, so it is not encoded as yerr.
    ax.vlines(x, low, high, color=color, linewidth=1.05, zorder=3)
    for center, lower, upper in zip(x, low, high):
        ax.hlines([lower, upper], center - 0.15, center + 0.15,
                  color=color, linewidth=1.05, zorder=3)


def _variance_panel(ax, summary, target):
    for j, group in enumerate(GROUPS):
        rows = [_cell(summary, group, float(tau), target) for tau in TAUS]
        factor = 100 / rows[0]["reference"] if target == "primary_pulse" else 1000
        if any(r["valid_count"] != 30 for r in rows):
            raise ValueError("Missing target outcomes require explicit display.")
        prediction = np.array([r["predicted_sd"] for r in rows]) * factor
        empirical = np.array([r["empirical_sd"] for r in rows]) * factor
        interval = np.array([[r["sd_bootstrap_low"], r["sd_bootstrap_high"]]
                             for r in rows], dtype=float).T * factor
        if not np.isfinite(interval).all():
            raise ValueError("The stored standard-deviation intervals must be finite.")
        x = 1000 * TAUS
        # Small display offsets separate overlapping intervals; nominal times
        # and the theory curves retain the true calibration spacing.
        centers = x + (j - 1) * 0.23
        ax.plot(x, prediction, color=COLORS[group], linestyle=(0, (4, 2)),
                linewidth=1.35, zorder=2)
        _intervals(ax, centers, interval[0], interval[1], COLORS[group])
        ax.scatter(centers, empirical, marker=MARKERS[group], s=27,
                   color=COLORS[group], edgecolors="white", linewidths=0.55, zorder=4)
    _tau_axis(ax)


def _branch_panel(ax, data):
    missing_counts = []
    medians = []
    jitter = np.random.default_rng(7643).uniform(-0.18, 0.18, 30)
    for j, group in enumerate(GROUPS):
        rows = sorted((r for r in data["records"]
                       if r["group"] == group and r["tau"] == 0.02), key=lambda r: r["seed"])
        values = np.array([r["saddle_branch_relative_rmse"] for r in rows]) * 100
        if len(values) != 30 or not np.isfinite(values).all() or np.any(values <= 0):
            raise ValueError("All 30 positive, finite branch errors must be shown.")
        missing = np.array([r["branch_missing_count"] > 0 for r in rows])
        missing_counts.append(int(missing.sum()))
        q10, median, q90 = np.quantile(values, [0.1, 0.5, 0.9])
        medians.append(float(median))
        ax.vlines(j, q10, q90, color=COLORS[group], linewidth=2.0, zorder=2)
        ax.hlines([q10, q90], j - 0.065, j + 0.065,
                  color=COLORS[group], linewidth=1.1, zorder=2)
        ax.scatter(j + jitter[~missing], values[~missing], marker=MARKERS[group],
                   s=15, color=COLORS[group], alpha=0.50, linewidths=0, zorder=3)
        ax.scatter(j + jitter[missing], values[missing], marker="^", s=27,
                   facecolors="white", edgecolors=COLORS[group], linewidths=0.85, zorder=4)
        ax.scatter([j], [median], marker=MARKERS[group], s=40, color=COLORS[group],
                   edgecolors="white", linewidths=0.8, zorder=5)
    ax.set_xticks([0, 1, 2], ["Ordinary", r"$\mu=0.45$", r"$\mu=0.735$"])
    ax.tick_params(axis="x", length=0, pad=5)
    ax.set_xlim(-0.48, 2.48)
    ax.set_ylabel("Saddle relative RMSE (%)")
    ax.text(0.98, 0.97, r"$\tau=0.02$", transform=ax.transAxes,
            ha="right", va="top", fontsize=9)
    _log_axis(ax, [0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50], (0.075, 65))
    return missing_counts, medians


def _inflation_panel(ax, summary):
    for j, group in enumerate(GROUPS):
        rows = [_cell(summary, group, float(tau), "primary_pulse", "degradation")
                for tau in TAUS[1:]]
        empirical = np.array([r["empirical_sd_inflation"] for r in rows])
        prediction = np.array([1.0] + [r["predicted_sd_inflation"] for r in rows])
        interval = np.array([[r["bootstrap_low"], r["bootstrap_high"]]
                             for r in rows], dtype=float).T
        if not np.isfinite(interval).all():
            raise ValueError("The stored inflation intervals must be finite.")
        centers = 1000 * TAUS[1:] + (j - 1) * 0.23
        ax.plot(1000 * TAUS, prediction, color=COLORS[group],
                linestyle=(0, (4, 2)), linewidth=1.35, zorder=2)
        _intervals(ax, centers, interval[0], interval[1], COLORS[group])
        ax.scatter(centers, empirical, marker=MARKERS[group], s=27,
                   color=COLORS[group], edgecolors="white", linewidths=0.55, zorder=4)
    ax.axhline(1, color="#A8ADB3", linewidth=0.7, zorder=1)
    ax.set_ylim(0.72, 5.45)
    ax.set_yticks([1, 2, 3, 4, 5])
    ax.set_ylabel(r"SD$(P_c;\tau)$ / SD$(P_c;0)$")
    _tau_axis(ax)


def render():
    """Return the four-panel figure, with saved fits and intervals unchanged."""
    data, summary = _load()
    with plt.rc_context(RC):
        fig, axes = plt.subplots(2, 2, figsize=(7.0, 6.0))
        _variance_panel(axes[0, 0], summary, "primary_pulse")
        axes[0, 0].set_ylabel(r"Relative SD of $P_c$ (%)")
        _log_axis(axes[0, 0], [0.2, 0.5, 1, 2, 5, 10, 20], (0.15, 24))
        _panel(axes[0, 0], "a", "Erasure threshold")
        _variance_panel(axes[0, 1], summary, "fold")
        axes[0, 1].set_ylabel(r"SD of $\mu_f$ ($\times10^{-3}$)")
        _log_axis(axes[0, 1], [0.5, 1, 2, 5, 10, 20], (0.3, 24))
        _panel(axes[0, 1], "b", "Fold location")
        counts, medians = _branch_panel(axes[1, 0], data)
        _panel(axes[1, 0], "c", "Saddle branch")
        _inflation_panel(axes[1, 1], summary)
        _panel(axes[1, 1], "d", "Uncertainty inflation")
        fig.subplots_adjust(left=0.105, right=0.982, bottom=0.10, top=0.84,
                            wspace=0.38, hspace=0.50)
        designs = [Line2D([], [], color=COLORS[g], marker=MARKERS[g], linestyle="none",
                          markersize=5, label=LABELS[g]) for g in GROUPS]
        fig.legend(handles=designs, loc="upper center", bbox_to_anchor=(0.54, 0.995),
                   ncol=3, columnspacing=1.25, handletextpad=0.4)
        empirical_key = axes[0, 0].errorbar([], [], yerr=np.empty((2, 0)),
                                           color="#30343B", marker="o", linestyle="none",
                                           markersize=4, capsize=2, linewidth=0.9,
                                           label="95% bootstrap (a,b,d)")
        meanings = [empirical_key,
                    Line2D([], [], color="#30343B", linestyle=(0, (4, 2)),
                           linewidth=1.35, label="Local prediction"),
                    Line2D([], [], color="#30343B", marker="^", linestyle="none",
                           markerfacecolor="white", markersize=5, label="Incomplete branch")]
        fig.legend(handles=meanings, loc="upper center", bbox_to_anchor=(0.54, 0.945),
                   ncol=3, columnspacing=1.2, handletextpad=0.5)
        fig._calibration_metadata = {"fits_per_cell": 30, "total_saved_fits": 270,
                                     "branch_points": 90, "incomplete_counts": counts,
                                     "branch_median_percent": medians,
                                     "nominal_tau": TAUS.tolist()}
    return fig
