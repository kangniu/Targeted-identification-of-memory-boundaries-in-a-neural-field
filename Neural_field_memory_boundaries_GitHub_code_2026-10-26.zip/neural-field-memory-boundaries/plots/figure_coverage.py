"""Figure 3: fixed rate-observation coverage, using saved records only.

``render()`` returns a seven-inch-wide matplotlib figure.  It neither saves
files nor imports the simulation or fitting code.
"""
from pathlib import Path
import json

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter, LogLocator, NullFormatter
import numpy as np


DATA_PATH = Path(__file__).resolve().parents[1] / "boundary_followup" / "results.json"
GROUPS = ("ordinary_14", "critical_shift_low", "critical_half", "critical_shift_high")
COLORS = {
    "ordinary_14": "#6B7280",
    "critical_shift_low": "#0072B2",
    "critical_half": "#D55E00",
    "critical_shift_high": "#009E73",
}
MARKERS = {
    "ordinary_14": "o",
    "critical_shift_low": "s",
    "critical_half": "D",
    "critical_shift_high": "^",
}
SHORT = ("O", r"$C_-$", "C", r"$C_+$")
STYLE = {
    "font.family": "serif",
    "font.serif": ["STIXGeneral", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 9.5,
    "axes.labelsize": 9.5,
    "axes.titlesize": 9.5,
    "xtick.labelsize": 8.5,
    "ytick.labelsize": 8.5,
    "legend.fontsize": 8.5,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 0.65,
    "axes.edgecolor": "#434952",
    "xtick.direction": "out",
    "ytick.direction": "out",
    "xtick.major.size": 3,
    "ytick.major.size": 3,
    "xtick.major.width": 0.65,
    "ytick.major.width": 0.65,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
}


def _panel(ax, letter, title):
    ax.set_title(r"$\mathbf{(" + letter + r")}$  " + title, loc="left", pad=8)
    ax.set_axisbelow(True)
    ax.grid(axis="y", which="major", color="#E2E5E8", linewidth=0.5)
    ax.tick_params(pad=3)


def _metric_values(rows, key, scale):
    if key == "principal_erasure":
        values = np.asarray([row["pulse_relative_errors"][2] for row in rows], dtype=float)
    else:
        values = np.asarray([row[key] for row in rows], dtype=float)
    # Missing or zero values must receive an explicit treatment if the source
    # records change; never silently drop a fit to accommodate the log axis.
    if len(values) != 30 or not np.all(np.isfinite(values)) or np.any(values <= 0):
        raise ValueError(f"Expected all 30 finite positive saved values for {key}.")
    return scale * values


def _distribution(ax, rows_by_group, key, scale, ylabel):
    jitter = np.random.default_rng(841).uniform(-0.20, 0.20, 30)
    extent = []
    for index, group in enumerate(GROUPS):
        values = _metric_values(rows_by_group[group], key, scale)
        extent.extend(values)
        color, marker = COLORS[group], MARKERS[group]
        ax.scatter(index + jitter, values, marker=marker, s=12,
                   facecolors=color, edgecolors="none", alpha=0.43, zorder=3)
        low, median, high = np.quantile(values, [0.10, 0.50, 0.90])
        ax.errorbar(index, median, yerr=[[median - low], [high - median]],
                    fmt="none", ecolor=color, elinewidth=1.4, capsize=4,
                    capthick=1.2, zorder=4)
        ax.scatter(index, median, marker=marker, s=42, facecolors=color,
                   edgecolors="white", linewidths=0.8, zorder=5)
    ax.set_yscale("log")
    ax.set_ylim(min(extent) / 1.7, max(extent) * 1.8)
    ax.yaxis.set_major_locator(LogLocator(base=10, subs=(1,), numticks=9))
    ax.yaxis.set_minor_locator(LogLocator(base=10, subs=(2, 5), numticks=30))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _position: f"{value:g}"))
    ax.yaxis.set_minor_formatter(NullFormatter())
    ax.set_xticks(np.arange(len(GROUPS)), SHORT)
    ax.set_xlim(-0.55, 3.55)
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", length=0, pad=5)


def _added_paths(ax, design):
    for group in GROUPS[1:]:
        paths = design[group]["paths"]
        if len(paths) != 2:
            raise ValueError("The saved coverage comparison must have two added paths.")
        for index, path in enumerate(paths):
            time = np.asarray(path["t"], dtype=float)
            amplitude = np.asarray(path["amplitude"], dtype=float)
            ax.plot(time, amplitude, color=COLORS[group],
                    linestyle="-" if index == 0 else "--", linewidth=1.35,
                    marker=MARKERS[group], markevery=6, markersize=3.2,
                    markeredgewidth=0.45, markeredgecolor="white")
    ax.set(xlabel=r"Time, $t$", ylabel=r"Synaptic amplitude, $A$",
           xlim=(0, 6), ylim=(0, 1.85))
    ax.set_xticks([0, 2, 4, 6])
    ax.set_yticks([0, 0.5, 1.0, 1.5])
    path_handles = [
        Line2D([], [], color="#434952", linestyle="-", linewidth=1.2,
               label=r"$\mu=0.72+\delta$"),
        Line2D([], [], color="#434952", linestyle="--", linewidth=1.2,
               label=r"$\mu=0.75+\delta$"),
    ]
    ax.legend(handles=path_handles, loc="upper left", frameon=False,
              handlelength=2.2, labelspacing=0.30, borderpad=0.1)
    # Endpoints and saved rate signs were checked before assigning outcomes:
    # C- ends at (1.546, 1.407); C at (1.518, 0.369);
    # C+ at (1.480, 0.043).  Both C- rates remain positive.
    ax.text(0.05, 0.20, r"$C_-$: both recover", color=COLORS[GROUPS[1]],
            transform=ax.transAxes, fontsize=8.5, va="center")
    ax.text(0.05, 0.085, r"$C,\ C_+$: recovery and decay", color="#333B42",
            transform=ax.transAxes, fontsize=8.5, va="center")


def render():
    """Return Fig. 3 from the original saved thirty-repeat comparison."""
    with DATA_PATH.open(encoding="utf-8") as stream:
        data = json.load(stream)
    rows_by_group = {
        group: sorted((row for row in data["records"] if row["group"] == group),
                      key=lambda row: row["seed"])
        for group in GROUPS
    }
    expected_seeds = set(data["protocol"]["seeds"])
    for group, rows in rows_by_group.items():
        if len(rows) != 30 or {row["seed"] for row in rows} != expected_seeds:
            raise ValueError(f"Incomplete saved repetitions for {group}.")
    with mpl.rc_context(STYLE):
        fig, axes = plt.subplots(2, 2, figsize=(7.0, 5.1))
        _added_paths(axes[0, 0], data["protocol"]["design"])
        _panel(axes[0, 0], "a", "Added trajectories")
        for ax, letter, key, scale, title, ylabel in [
            (axes[0, 1], "b", "saddle_branch_relative_rmse", 100,
             "Saddle-branch error", "Relative RMSE (%)"),
            (axes[1, 0], "c", "fold_absolute_error", 1000,
             "Fold-location error", r"Absolute error in $\mu_f$ ($\times10^{-3}$)"),
            (axes[1, 1], "d", "principal_erasure", 100,
             "Erasure-threshold error", "Relative error (%)"),
        ]:
            _distribution(ax, rows_by_group, key, scale, ylabel)
            _panel(ax, letter, title)
        legend_labels = [
            "O: ordinary", r"$C_-:\ \delta=-0.01$", r"$C:\ \delta=0$",
            r"$C_+:\ \delta=0.01$",
        ]
        handles = [Line2D([], [], color=COLORS[group], marker=MARKERS[group],
                          linestyle="none", markersize=5, label=label)
                   for group, label in zip(GROUPS, legend_labels)]
        fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.53, 0.995),
                   ncol=4, frameon=False, handletextpad=0.45, columnspacing=1.65)
        fig.subplots_adjust(left=0.105, right=0.985, bottom=0.08, top=0.885,
                            hspace=0.43, wspace=0.39)
    return fig
