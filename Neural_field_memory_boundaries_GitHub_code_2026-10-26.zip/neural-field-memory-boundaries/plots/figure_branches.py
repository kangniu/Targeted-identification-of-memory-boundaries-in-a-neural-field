"""Reference geometry and learned branches, with conditional sample counts."""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.special import expit
from model import RingField, TRUE_PARAMETERS

BLUE, ORANGE, GRAY = '#0072B2', '#D55E00', '#6B7280'


def panel(ax, letter, title):
    ax.set_title(r'$\mathbf{(' + letter + r')}$  ' + title, loc='left', pad=8)


def render(data):
    field = RingField(512)
    saddle, stable = field.equilibria(.60, TRUE_PARAMETERS)
    ref = data['protocol']['reference']
    mu = np.asarray(ref['branch_mu'])
    reference = np.asarray(ref['branch'])
    fig = plt.figure(figsize=(7., 5.35))
    grid = fig.add_gridspec(2, 2, height_ratios=[1.65, 2.25],
                            left=.095, right=.985, bottom=.095, top=.94,
                            wspace=.30, hspace=.56)
    lower = grid[1, :].subgridspec(2, 1, height_ratios=[1.85, .30], hspace=.12)
    ax = fig.add_subplot(grid[0, 0])
    x = np.linspace(-np.pi, np.pi, 601)
    for amplitude, color, style, label in [
            (stable, BLUE, '-', r'Memory $A_+$'),
            (saddle, ORANGE, '--', r'Boundary $A_-$'),
            (0., GRAY, ':', 'Quiet state')]:
        firing = expit(10 * (amplitude*np.cos(x)-.60-.15))
        ax.plot(x, firing, color=color, ls=style, lw=1.5, label=label)
    ax.set(xlabel=r'Position, $x$', ylabel='Firing rate', ylim=(-.035, 1.06))
    ax.set_xticks([-np.pi, 0, np.pi], [r'$-\pi$', '0', r'$\pi$'])
    ax.set_yticks([0, .5, 1])
    ax.legend(loc='upper left', fontsize=8, handlelength=1.3,
              handletextpad=.4, labelspacing=.3, borderpad=.15)
    panel(ax, 'a', r'Localized states at $\mu=0.60$')

    ax = fig.add_subplot(grid[0, 1])
    a = np.linspace(0, 2.05, 601)
    f = field.g(a, .60, TRUE_PARAMETERS)
    ax.axhline(0, color='#9AA0A6', lw=.65, zorder=0)
    ax.plot(a, f, color='#252525', lw=1.4)
    ax.fill_between(a, f, 0, where=(a <= saddle), color=GRAY, alpha=.10)
    ax.fill_between(a, f, 0, where=(a >= saddle), color=BLUE, alpha=.08)
    for root, color, fill in [(0., GRAY, GRAY), (saddle, ORANGE, 'white'),
                               (stable, BLUE, BLUE)]:
        ax.plot(root, 0, 'o', color=color, mfc=fill, ms=5, mew=1.1,
                clip_on=False, zorder=5)
    for left, right in [(.38, .15), (1.08, 1.4), (2.0, 1.82)]:
        ax.annotate('', xy=(right, .105), xytext=(left, .105),
                    arrowprops=dict(arrowstyle='->', lw=.9, color='#333333'))
    ax.text(saddle, -.09, r'$A_-$', ha='center', va='top', color=ORANGE)
    ax.text(stable, -.09, r'$A_+$', ha='center', va='top', color=BLUE)
    ax.text(.33, -.49, 'Decay', color=GRAY, ha='center', fontsize=8.5)
    ax.text(1.28, .31, 'Recovery', color=BLUE, ha='center', fontsize=8.5)
    ax.set(xlabel=r'Amplitude, $A$', ylabel=r'$F(A,0.60;p_*)$',
           xlim=(-.03, 2.05), ylim=(-.58, .52))
    ax.set_xticks([0, .5, 1, 1.5, 2])
    ax.set_yticks([-.5, 0, .5])
    panel(ax, 'b', 'The boundary separates the basins')

    ax = fig.add_subplot(lower[0])
    counts = {}
    for group, color in [('ordinary', GRAY), ('adaptive_boundary', ORANGE)]:
        rows = [r for r in data['records'] if r['sigma'] == .02 and r['group'] == group]
        assert len(rows) == 30
        values = np.asarray([r['branch'] for r in rows], dtype=float)
        counts[group] = np.isfinite(values).all(axis=2).sum(axis=0)
        for k, style in [(0, '--'), (1, '-')]:
            low, med, high = np.nanquantile(values[:, :, k], [.1, .5, .9], axis=0)
            ax.fill_between(mu, low, high, color=color, alpha=.17, linewidth=0)
            ax.plot(mu, med, color=color, lw=1.5, ls=style,
                    marker='s' if group == 'ordinary' else 'D',
                    markevery=6, ms=3.0, mfc='white', mew=.8, zorder=4)
    for k, style in [(0, '--'), (1, '-')]:
        ax.plot(mu, reference[:, k], color='#151515', lw=1.0, ls=style, zorder=3)
    ax.set(ylabel=r'Amplitude, $A$', xlim=(.295, .745), ylim=(-.025, 2.03))
    ax.set_yticks([0, .5, 1, 1.5, 2])
    ax.tick_params(labelbottom=False)
    ax.grid(axis='y', color='#E2E5E8', lw=.5, zorder=0)
    panel(ax, 'c', r'Branch reconstruction at $\sigma=0.02$')
    ax.legend(handles=[Line2D([], [], color='#151515', label='Reference'),
                       Line2D([], [], color=GRAY, marker='s', mfc='white',
                              ms=3.5, label='Ordinary'),
                       Line2D([], [], color=ORANGE, marker='D', mfc='white',
                              ms=3.5, label='Adaptive')],
              loc='lower right', ncol=3, handlelength=1.9,
              columnspacing=1.1, fontsize=8.5)
    ax.text(.307, 1.65, 'Stable memory', fontsize=8.5,
            bbox=dict(fc='white', ec='none', alpha=.85, pad=.8))
    ax.text(.50, .42, 'Unstable boundary', fontsize=8.5,
            bbox=dict(fc='white', ec='none', alpha=.85, pad=.8))

    count_ax = fig.add_subplot(lower[1], sharex=ax)
    for group, color, style in [('ordinary', GRAY, '-'),
                                 ('adaptive_boundary', ORANGE, '--')]:
        count_ax.step(mu, counts[group], where='mid', color=color,
                      lw=1.1, ls=style, clip_on=False)
    count_ax.set(ylim=(21, 31), xlabel=r'Threshold parameter, $\mu$')
    count_ax.set_yticks([22, 30])
    count_ax.set_ylabel('Pairs\n(out of 30)', fontsize=8, labelpad=10)
    count_ax.set_xticks([.3, .4, .5, .6, .7])
    count_ax.spines['left'].set_visible(False)
    count_ax.tick_params(axis='y', length=0, labelsize=7.5)
    return fig, {'profile_mu': .60, 'profile_roots': [float(saddle), float(stable)],
                 'valid_pair_counts': {k: v.tolist() for k, v in counts.items()}}
